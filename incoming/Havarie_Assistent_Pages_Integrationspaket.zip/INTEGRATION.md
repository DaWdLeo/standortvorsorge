# Havarie-Assistent – GitHub-Pages-Staging (ohne Veröffentlichung)

Ausgangsdatei: `Havarie_Assistent_Webfrontend_D2_Pages_neutral.zip`.

## Installation in bestehendes Repository

Dieses Paket enthält ausschließlich die statische, neutrale Web-App im Unterordner `assistent-v2/`.
Im Repository `DaWdLeo/standortvorsorge` kann der Ordner zu Testzwecken auf einem **separaten Entwicklungsbranch** hinzugefügt werden. Der bestehende Branch `main` soll erst nach Abnahme geändert werden.

Für GitHub Pages, das den Repository-Root veröffentlicht, wäre die neue Fassung nach Übernahme in main unter `https://dawdleo.github.io/standortvorsorge/assistent-v2/` erreichbar.

Homarr-iFrame (nach Veröffentlichung):

```html
<iframe src="https://dawdleo.github.io/standortvorsorge/assistent-v2/?embed=1" title="Havarie-Assistent – Demo" style="width:100%;height:900px;border:0" loading="lazy" allow="clipboard-write"></iframe>
```

## Enthalten / nicht enthalten

- Enthalten: HTML/CSS/JavaScript, neutraler exportierter Datenbestand, Browser-Rechenkern, CSV/XLSX-Katasterimport, Embed-Script.
- Nicht enthalten: Excel-Master, Python-/FastAPI-Server, Arbeitskopien, Freigabeunterlagen und operative Notfallanweisungen.
- Beispielregeln und -maßnahmen im exportierten Bestand tragen teils bereits Status `Aktiv`/`Freigegeben` aus dem Testmaster. Das **ist keine echte fachliche Freigabe**. Keine reale Entscheidung darauf stützen.
- Neue Regel- oder Maßnahmenentwürfe dürfen nur mit Status `Entwurf` erstellt werden und benötigen die Prüfung anhand des separat vorliegenden Regelentwicklungs-Prompts.
- Browserdaten in `localStorage` sind nicht vertraulich abgesichert oder geräteübergreifend synchronisiert. Nur fiktive Daten verwenden.

## Prüfstand

- `node --check`: ohne Syntaxfehler in den JS-Dateien.
- `node --test tests/web/test_kataster.js`: 11/11 erfolgreich, bezogen auf das vollständige Quellpaket.
- HTML-Verweise auf lokale JS/CSS-Dateien: ohne fehlende Referenzen.
- Browser-E2E und Excel-Konformität: bei dieser Integrationsvorbereitung **nicht erneut verifiziert**.

Sicherheit: GitHub Pages und öffentliche Repository-Dateien nicht für private Standorte oder Betriebsdaten verwenden.
